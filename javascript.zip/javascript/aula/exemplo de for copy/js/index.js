for(i=0 ; i<5 ; i++)
    document.write(i, "<br>")