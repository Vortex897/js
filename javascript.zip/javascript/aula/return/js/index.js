function produto(a,b)
{
    var c;
    c = a * b;
    return c;
}

result = produto(4,3);
document.write(result);