let a = parseInt(prompt("Informe o primeiro número"));
let b = parseInt(prompt("Informe o segundo número"));

let c = a + b

document.write(a+" + "+b+" = "+c)