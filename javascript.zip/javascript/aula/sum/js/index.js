let a = 25;
let b = 78; 

let c = a + b

document.write("<h1>A soma de "+a+" + "+b+" é "+c+".</h1>");
alert("A soma de "+a+" + "+b+" é "+c+".");