for(i = 1, fat = 1 ; i < 6 ; i++, fat *= i)
    document.write(i, "! = ", fat, "<br>")