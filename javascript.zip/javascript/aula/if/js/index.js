data = new Date();
hora = data.getHours();
if (hora<12) document.write("<b>Bom dia</b>");
if (hora>12)
    if (hora<18) document.write("<b>Boa tarde</b>");
if (hora>18) document.write("<b>Boa noite</b>");