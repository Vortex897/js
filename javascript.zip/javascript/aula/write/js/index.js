document.write("<title>Titulo da página</title>");
document.write("<h1>Isto é um cabeçalho</h1>");
document.write("<p>Isto é um parágrafo</p>");
document.write("<p>Isto outro parágrafo</p>");
// window.alert("Senha incorreta, acesso negado");
alert("Senha incorreta, acesso negado");