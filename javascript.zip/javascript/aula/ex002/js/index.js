for(i=0 ; i<26 ; i++)
    if(i % 2 == 0){
        document.write(i, "<br>")
    }
    